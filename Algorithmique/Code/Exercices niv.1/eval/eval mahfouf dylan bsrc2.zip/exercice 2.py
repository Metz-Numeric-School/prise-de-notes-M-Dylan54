n1=int(input("n1"))
n2=int(input("n2"))
if n1<n2:
    print("Le nombre 1 est inferieur au nombre 2")
if n1==n2:
    print("Le nombre 1 est egal au nombre 2")
if n1>n2:
    print("Le nombre 1 est divisible au nombre 2")