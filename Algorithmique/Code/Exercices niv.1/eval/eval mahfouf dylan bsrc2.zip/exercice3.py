n1=float(input("nombre1"))
n2=float(input("nombre2"))
print(n1+n2)
print(n1-n2)
print(n1*n2)
if n2==0:
    print("erreur : division par 0")
else:
    print(n1/n2)

