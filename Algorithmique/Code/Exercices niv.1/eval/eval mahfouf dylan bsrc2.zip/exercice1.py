
nom =str(input("quel est votre nom ?"))
age =int(input("quel âge avez-vous ?"))
taille =float(input("quelle taille mesurez-vous?"))
print(type(nom))
print(type(age))
print(type(taille))
print("Bonjour, je m'appelle" + (nom) "")
