a=True
b=False
c=True
if (a and c) == True :
    print("la condition a ET c est vraie")

if (a or b) == True :
    print("la condition a ET b est vraie")

if (b and c) == False :
    print("la condition b ET c est fausse")


    




