prix=float(input("donnez-moi le prix hors taxe"))
print(prix*1.2)