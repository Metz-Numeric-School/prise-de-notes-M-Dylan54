Francais=float(input("Saisir note de français"))
Math=float(input("Saisir note de maths"))
Geo=float(input("Saisir note de géometrie"))
info=float(input("Saisir note d'informatique"))
Moyenne=(Francais+Math+Geo+info)/4
print(Moyenne)