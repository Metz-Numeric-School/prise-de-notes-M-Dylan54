longueur=float(input("Donnez moi la longueur"))
largeur=float(input("Donnez moi la largeur"))
hauteur=float(input("Donnez moi la hauteur"))
volume=longueur*largeur*hauteur
print(volume)
