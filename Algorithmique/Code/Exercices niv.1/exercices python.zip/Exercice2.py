nombre=float(input("saisissez un nombre"))
print(nombre*2)