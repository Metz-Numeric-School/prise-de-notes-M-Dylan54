x=float(input("saisir une longueur"))
print(x**2)