prénom=input("quel est votre nom ?")
str(print("Hello",prénom))