age=int(input("quelle est l'année de votre naissance ?"))
print(2024-age)