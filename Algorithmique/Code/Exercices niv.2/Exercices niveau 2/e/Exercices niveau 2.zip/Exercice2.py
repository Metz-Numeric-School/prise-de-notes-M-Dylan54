a=float(input("premier nombre"))
b=float(input("second nombre"))
c=float(input("troisième nombre"))
if a<=b<=c:
    print("Les nombres sont dans l'ordre croissant")
else:
    print("Les nombre ne sont pas dans l'ordre croissant")
