nombre=float(input("Saisir un nombre"))
if nombre<0 :
    print("Négatif")
if nombre==0 :
    print("Nul")
if nombre>0 :
    print("Positif")