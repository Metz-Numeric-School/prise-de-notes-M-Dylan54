tempambiante=float(input("Saisir la température ambiante"))
tempbassin=float(input("Saisir la température du bassin"))
difference=tempambiante-tempbassin
if difference<20 or difference>40:
    print(difference, "°C")
    print("ALAAAAAAAAAAAAAAAAAAAAARME")