anneenaissancebebe=float(input("en quelle année est né le bébé ?"))
agebebe=2024-anneenaissancebebe
if agebebe<3:
    print("le bébé gagne une palette")
else :
    print("le bebe ne gagne pas de palette")
    